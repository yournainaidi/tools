#codingutf-8
import os
import re


def todb():
    pass

def proline(content):
    pattern = r'([^@]*)@([^\s])\s*(.*)'
    matchObj = re.match( pattern, line)
    if matchObj:
        name = matchObj.group(1)
        suffix = matchObj.group(2)
        res = name + '#-#' + suffix + '\n'
        return res
    else:
        return False 
	

def pfile(file,fhash):
    cnt = 0
    tmp = ''
    with open(file,mode="rb") as f2:
        for line in f2:
            res = proline(line)
            if(not res):
                cnt = cnt + 1
            else:
                tmp = tmp + res
            if cnt > 10000:
                return False
    if tmp=='':
        pass
    else:
        #write to file
        newf = "D:\\1\\"+fhash + '.txt'
        with open(newf,mode="a+",encoding='utf-8') as f:
            f.write(tmp)
        #write to db
				
if __name__ == '__main__':

    all = 'data.txt'
    err = 'err.txt'
    errset = set()
    with open(all,mode="r",encoding='utf-8') as f:
        for line in f:
            fhash = line[:32]
            errset.add(fhash)			
    with open(all,mode="r",encoding='utf-8') as f:
        for line in f:
            fhash = line[:32]
            if fhash in errset:
                continue
            file = line[33:-1]
            print(file)
            if(not pfile(file,fhash)):
                with open(err,mode="a+",encoding='utf-8') as f:
                    f.write(line)
                 
