#codingutf-8
import os
import hashlib 


def traversal(path,txt):
    items =os.listdir(path)
    files = []
    dirs = []
    for item in items:
        item = os.path.join(path,item)
        if os.path.isdir(item):
            dirs.append(item)
        elif os.path.isfile(item):
            files.append(item)
    for file in files:
        fhash = getHash(file)
        if fhash in hset:
            #print(file)
            pass
        else:
            hset.add(fhash)
            print(file)
            with open(txt,mode="a+",encoding='utf-8') as f:
                data = '{} {}\n'.format(fhash,file)
                f.write(data)
    for directory in dirs:
        traversal(directory, txt)


                               
def getHash(file_name):
    with open(file_name, 'rb') as fp:
        data = fp.read()
    file_md5= hashlib.md5(data).hexdigest()
    return file_md5


if __name__ == '__main__':
    path = 'D:\\code\\'
    txt = 'data.txt'
    if(not os.path.exists(txt)):
        with open(txt,mode="a+",encoding='utf-8'):
            pass  
    hset = set()	
    with open(txt,mode="r",encoding='utf-8') as f:
        for line in f:
            hset.add(line.split()[0])
    traversal(path,txt)

