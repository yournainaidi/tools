#coding:utf-8

import chardet
import os


path = 'C:\\Users\\sb\\Desktop\\test\\'
file = 'C:\\Users\\sb\\Desktop\\test\\2.txt'
tmpfile = 'C:\\Users\\sb\\Desktop\\test\\tmp.txt'

def change_coding(file, coding='GB18030',tmp_file_name='tmp.txt'):
    """
    文件编码转换,将文件编码转换为UTF-8
    :param file:
    :return:
    """
    tmpfile = os.path.join(os.path.dirname(file), tmp_file_name)
    try:
        with open(file, 'r', encoding=coding) as fr, open(tmpfile, 'w', encoding='utf-8') as fw:
            content=fr.read()
            content=str(content.encode('utf-8'),encoding='utf-8')
            print(content,file=fw)
    except UnicodeDecodeError as e:
        print(file+': ' + e.reason)
    
    fw.close()
    fr.close()
    return tmpfile



def processf(file):
    with open(file,mode="rb") as f:
        c = f.read()
        chardet_1 = chardet.detect(c)
        ecd = chardet_1['encoding']
        print(ecd)
        if ecd != 'utf-8':
            change_coding(file,ecd)
            return True
            
items =os.listdir(path)
for one in items:
    file = os.path.join(path,one)         
    if processf(file):
        print(file)
        os.remove(file)
        os.rename(tmpfile, file)





        
        
        